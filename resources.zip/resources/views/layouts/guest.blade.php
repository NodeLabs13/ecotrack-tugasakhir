<!DOCTYPE html>
<html lang="id" class="h-full overflow-hidden">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title') - Eco Track</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Inter', sans-serif; 
            background-color: #020617;
            height: 100vh;
            width: 100vw;
            overflow: hidden;
            color: white;
        }
        
        .bg-container {
            position: fixed;
            inset: 0;
            z-index: -1;
            background: #020617;
            overflow: hidden;
        }

        .mesh-gradient {
            position: absolute;
            width: 100%;
            height: 100%;
            filter: blur(100px);
            opacity: 0.5;
        }

        .blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            transition: transform 0.6s cubic-bezier(0.23, 1, 0.32, 1);
            pointer-events: none;
        }
        .blob-1 { width: 60vw; height: 60vw; background: #1e40af; top: -20%; left: -10%; opacity: 0.6; }
        .blob-2 { width: 50vw; height: 50vw; background: #0891b2; bottom: -10%; right: -10%; opacity: 0.4; }
        .blob-3 { width: 40vw; height: 40vw; background: #4f46e5; top: 20%; left: 30%; opacity: 0.3; }

        .grid-overlay {
            position: absolute;
            inset: 0;
            background-image: radial-gradient(rgba(255, 255, 255, 0.05) 1px, transparent 1px);
            background-size: 30px 30px;
            mask-image: radial-gradient(circle at center, black, transparent 80%);
        }

        .noise {
            position: absolute;
            inset: 0;
            background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E");
            opacity: 0.03;
            pointer-events: none;
        }

        .glass-card { 
            background: rgba(255, 255, 255, 0.03); 
            backdrop-filter: blur(12px); 
            border: 1px solid rgba(255, 255, 255, 0.08); 
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
        }

        .form-glass { 
            background: rgba(15, 23, 42, 0.6); 
            backdrop-filter: blur(20px); 
            border: 1px solid rgba(255, 255, 255, 0.1); 
        }

        .btn-glow {
            background: linear-gradient(135deg, #3b82f6 0%, #06b6d4 100%);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .btn-glow:hover { 
            transform: translateY(-2px); 
            box-shadow: 0 0 20px rgba(59, 130, 246, 0.5);
            filter: brightness(1.1);
        }

        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: rgba(255, 255, 255, 0.05); }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.1); border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(255, 255, 255, 0.2); }
    </style>
    @yield('styles')
</head>
<body class="flex flex-col h-screen overflow-hidden">
    <!-- Background Layers -->
    <div class="bg-container">
        <div class="mesh-gradient">
            <div id="blob1" class="blob blob-1"></div>
            <div id="blob2" class="blob blob-2"></div>
            <div id="blob3" class="blob blob-3"></div>
        </div>
        <div class="grid-overlay"></div>
        <div class="noise"></div>
    </div>

    @yield('content')

    <script>
        const b1 = document.getElementById('blob1');
        const b2 = document.getElementById('blob2');
        const b3 = document.getElementById('blob3');
        
        document.addEventListener('mousemove', (e) => {
            const x = e.clientX / window.innerWidth;
            const y = e.clientY / window.innerHeight;
            
            if(b1) b1.style.transform = `translate(${x * 50}px, ${y * 50}px)`;
            if(b2) b2.style.transform = `translate(${x * -70}px, ${y * -70}px)`;
            if(b3) b3.style.transform = `translate(${x * 30}px, ${y * -30}px)`;
        });
    </script>
    @yield('scripts')
</body>
</html>
