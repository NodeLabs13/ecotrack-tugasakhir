@extends('layouts.guest')
@section('title', 'Eco Track - Sistem Monitoring Proyek')

@section('content')
    <!-- Header Navbar -->
    <nav class="fixed top-0 left-0 w-full z-50 border-b border-white/5 backdrop-blur-md bg-slate-950/50">
        <div class="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center shadow-lg flex-shrink-0">
                    <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                    </svg>
                </div>
                <span class="text-2xl font-extrabold text-white tracking-tight">Eco<span class="text-cyan-400">Track</span></span>
            </div>
            <div class="flex items-center gap-4">
                <a href="{{ route('login') }}" class="text-white/70 hover:text-white font-medium px-4 py-2 transition-colors text-sm">Masuk</a>
                <a href="{{ route('register') }}" class="btn-glow text-white font-bold px-6 py-2.5 rounded-xl text-sm shadow-lg">Daftar Sekarang</a>
            </div>
        </div>
    </nav>
    
    <main class="relative z-10 flex-1 flex flex-col lg:flex-row items-center pt-20 px-6 h-full overflow-hidden">
        <!-- Left Side - Hero Content -->
        <div class="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-8 lg:p-16 relative h-full">
            <div class="w-full max-w-2xl">
                <div class="mb-8">
                    <h1 class="text-5xl sm:text-6xl lg:text-7xl xl:text-8xl font-black text-white leading-tight mb-6 tracking-tighter">
                        Pantau Proyek <br><span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300">Lebih Cerdas.</span>
                    </h1>
                    <p class="text-white/60 text-xl sm:text-2xl font-medium max-w-xl leading-relaxed">
                        Platform monitoring real-time untuk efisiensi konstruksi dan pengelolaan dokumen terpusat.
                    </p>
                </div>

                <div class="grid grid-cols-3 gap-4 sm:gap-6 mb-10">
                    <div class="glass-card rounded-2xl p-4 sm:p-6 transform transition-all hover:scale-105">
                        <div class="text-3xl sm:text-4xl font-black text-white mb-1">150+</div>
                        <div class="text-white/40 text-xs sm:text-sm font-medium uppercase tracking-wider">Proyek</div>
                    </div>
                    <div class="glass-card rounded-2xl p-4 sm:p-6 transform transition-all hover:scale-105">
                        <div class="text-3xl sm:text-4xl font-black text-white mb-1">50+</div>
                        <div class="text-white/40 text-xs sm:text-sm font-medium uppercase tracking-wider">Klien</div>
                    </div>
                    <div class="glass-card rounded-2xl p-4 sm:p-6 transform transition-all hover:scale-105">
                        <div class="text-3xl sm:text-4xl font-black text-white mb-1">99%</div>
                        <div class="text-white/40 text-xs sm:text-sm font-medium uppercase tracking-wider">Akurasi</div>
                    </div>
                </div>

                <div class="flex flex-col sm:flex-row gap-4">
                    <a href="{{ route('login') }}" class="btn-glow text-white font-bold px-10 py-4 rounded-2xl text-center shadow-xl text-lg">
                        Mulai Sekarang
                    </a>
                </div>
            </div>
        </div>

        <!-- Right Side - Visual Decoration -->
        <div class="hidden lg:flex lg:w-1/2 items-center justify-center p-8 lg:p-16 relative h-full">
            <div class="relative z-10 w-full max-w-xl">
                <div class="relative group">
                    <div class="absolute inset-0 bg-blue-500/20 rounded-full blur-3xl group-hover:bg-blue-500/30 transition-all duration-500"></div>
                    <svg class="w-full h-auto max-h-[450px] relative z-10" viewBox="0 0 600 500" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <defs>
                            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="url(#gridGrad)" stroke-width="0.5" opacity="0.3"/>
                            </pattern>
                            <linearGradient id="gridGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#2563eb;stop-opacity:0.5" />
                                <stop offset="100%" style="stop-color:#06b6d4;stop-opacity:0.3" />
                            </linearGradient>
                            <linearGradient id="hubGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#2563eb;stop-opacity:1" />
                                <stop offset="100%" style="stop-color:#06b6d4;stop-opacity:1" />
                            </linearGradient>
                        </defs>
                        <rect width="600" height="500" fill="url(#grid)"/>
                        <circle cx="300" cy="250" r="60" fill="white" opacity="0.95" filter="drop-shadow(0 0 30px rgba(37,99,235,0.5))"/>
                        <circle cx="300" cy="250" r="50" fill="url(#hubGrad)"/>
                        <path d="M300 210 L278 232 L278 258 L322 258 L322 232 Z" fill="white"/>
                        <circle cx="300" cy="250" r="110" fill="none" stroke="#2563eb" stroke-width="2" opacity="0.4" stroke-dasharray="10,5"/>
                        <circle cx="300" cy="250" r="170" fill="none" stroke="#0891b2" stroke-width="1.5" opacity="0.3" stroke-dasharray="8,8"/>
                        <circle cx="410" cy="250" r="18" fill="#2563eb" opacity="0.9"/>
                        <circle cx="300" cy="140" r="18" fill="#06b6d4" opacity="0.9"/>
                        <circle cx="190" cy="250" r="18" fill="#10b981" opacity="0.9"/>
                        <circle cx="300" cy="360" r="18" fill="#f59e0b" opacity="0.9"/>
                    </svg>
                </div>
            </div>
        </div>
    </main>
@endsection
