@extends('layouts.app')
@section('title', 'Unggah Dokumen')

@section('content')
<div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 max-w-xl">
    <p class="text-sm text-gray-400 mb-5">Proyek: <span class="font-semibold text-gray-700">{{ $proyek->nama_proyek }}</span></p>
    <form method="POST" action="{{ route('dokumen.store', $proyek) }}" enctype="multipart/form-data" class="space-y-5">
        @csrf
    <div>
        <label class="text-sm font-medium text-gray-600">Nama Dokumen</label>
        <input type="text" name="nama_dokumen" value="{{ old('nama_dokumen') }}" required
            class="mt-1 w-full rounded-xl border-gray-200 border px-4 py-2.5 text-sm focus:border-primary-500 focus:ring-primary-100 focus:ring-4">
    </div>
    <div>
        <label class="text-sm font-medium text-gray-600">Jenis Dokumen</label>
        <input type="text" name="jenis_dokumen" value="{{ old('jenis_dokumen') }}" placeholder="Kontrak, Izin, Foto, dll"
            class="mt-1 w-full rounded-xl border-gray-200 border px-4 py-2.5 text-sm focus:border-primary-500 focus:ring-primary-100 focus:ring-4">
    </div>
    <div>
        <label class="text-sm font-medium text-gray-600">Berkas</label>
        <input type="file" name="berkas" required
            class="mt-1 w-full rounded-xl border-gray-200 border px-4 py-2.5 text-sm focus:border-primary-500 focus:ring-primary-100 focus:ring-4">
    </div>
        <div class="flex gap-3 pt-2">
            <button type="submit" class="bg-green-700 hover:bg-green-800 text-white font-semibold px-5 py-2.5 rounded-xl text-sm">Unggah</button>
            <a href="{{ route('proyek.show', $proyek) }}" class="text-sm text-gray-500 px-5 py-2.5">Batal</a>
        </div>
    </form>
</div>
@endsection
