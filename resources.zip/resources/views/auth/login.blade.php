@extends('layouts.guest')
@section('title', 'Login')

@section('content')
    <div class="relative z-10 w-full h-full flex flex-col lg:flex-row items-center justify-center px-6 overflow-hidden">
        <!-- Left Side - Branding -->
        <div class="hidden lg:flex lg:w-1/2 items-center justify-center p-8 lg:p-12 relative h-full">
            <div class="relative z-10 text-center max-w-2xl">
                <div class="mb-8">
                     <div class="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center shadow-2xl mb-6">
                        <svg class="w-14 h-14 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                        </svg>
                    </div>
                </div>
                <h3 class="text-4xl font-black text-white mb-4 tracking-tight">Eco<span class="text-cyan-400">Track</span></h3>
                <p class="text-white/60 text-lg max-w-md mx-auto leading-relaxed">
                    Masuk untuk mengelola dan memantau perkembangan proyek Anda secara real-time.
                </p>
            </div>
        </div>
        
        <!-- Right Side - Form Login -->
        <div class="w-full lg:w-1/2 flex items-center justify-center p-4 h-full">
            <div class="w-full max-w-md">
                <div class="form-glass rounded-3xl shadow-2xl p-8">
                    <h2 class="text-2xl font-bold text-white mb-1">Selamat Datang Kembali</h2>
                    <p class="text-sm text-white/50 mb-8">Masukkan kredensial Anda untuk melanjutkan</p>

                    @if ($errors->any())
                        <div class="mb-6 bg-red-500/20 border-l-4 border-red-500 text-red-200 px-4 py-3 rounded-xl text-sm">
                            <p class="font-medium">{{ $errors->first() }}</p>
                        </div>
                    @endif

                    <form method="POST" action="{{ route('login.submit') }}" class="space-y-6">
                        @csrf
                        <div>
                            <label class="text-sm font-semibold text-white/80 mb-2 block">Alamat Email</label>
                            <div class="relative">
                                <div class="absolute left-4 top-1/2 -translate-y-1/2 text-white/30">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                                    </svg>
                                </div>
                                <input type="email" name="email" value="{{ old('email') }}" required autofocus
                                    class="w-full pl-12 pr-4 py-3.5 rounded-xl bg-white/5 border-2 border-white/10 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/20 transition-all text-sm text-white placeholder-white/20"
                                    placeholder="nama@perusahaan.com">
                            </div>
                        </div>
                        
                        <div>
                            <label class="text-sm font-semibold text-white/80 mb-2 block">Password</label>
                            <div class="relative">
                                <div class="absolute left-4 top-1/2 -translate-y-1/2 text-white/30">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                                    </svg>
                                </div>
                                <input type="password" name="password" required
                                    class="w-full pl-12 pr-4 py-3.5 rounded-xl bg-white/5 border-2 border-white/10 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/20 transition-all text-sm text-white placeholder-white/20"
                                    placeholder="••••••••">
                            </div>
                        </div>
                        
                        <button type="submit"
                            class="w-full btn-glow text-white font-bold py-4 rounded-xl transition-all shadow-lg">
                            Masuk Ke Dashboard
                        </button>
                    </form>

                    <div class="relative my-8">
                        <div class="absolute inset-0 flex items-center"><div class="w-full border-t border-white/10"></div></div>
                        <div class="relative flex justify-center text-sm"><span class="px-4 bg-[#0f172a] text-white/40">Atau</span></div>
                    </div>

                    <a href="{{ route('register') }}" 
                        class="block w-full text-center bg-white/5 hover:bg-white/10 text-blue-400 font-semibold py-4 rounded-xl border-2 border-blue-500/30 transition-all">
                        Daftar Sebagai Klien Baru
                    </a>
                </div>
            </div>
        </div>
    </div>
@endsection
