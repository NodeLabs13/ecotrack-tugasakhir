@extends('layouts.guest')
@section('title', 'Daftar Akun Baru')

@section('content')
    <div class="relative z-10 w-full h-full flex flex-col lg:flex-row items-center justify-center px-6 overflow-hidden">
        <!-- Left Side - Info -->
        <div class="hidden lg:flex lg:w-1/2 items-center justify-center p-8 lg:p-12 h-full">
            <div class="max-w-lg">
                <h2 class="text-4xl font-black text-white mb-6 leading-tight">Mulai Perjalanan Proyek Anda <span class="text-blue-400">Bersama Kami.</span></h2>
                <div class="space-y-6">
                    <div class="flex items-start gap-4">
                        <div class="w-12 h-12 rounded-2xl bg-blue-500/20 flex items-center justify-center flex-shrink-0 text-blue-400 border border-blue-500/30">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        </div>
                        <div>
                            <h4 class="text-white font-bold text-lg">Monitoring Real-time</h4>
                            <p class="text-white/50 text-sm">Pantau progres lapangan setiap hari tanpa harus ke lokasi.</p>
                        </div>
                    </div>
                    <div class="flex items-start gap-4">
                        <div class="w-12 h-12 rounded-2xl bg-cyan-500/20 flex items-center justify-center flex-shrink-0 text-cyan-400 border border-cyan-500/30">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2"/></svg>
                        </div>
                        <div>
                            <h4 class="text-white font-bold text-lg">Arsip Dokumen Digital</h4>
                            <p class="text-white/50 text-sm">Semua dokumen perizinan dan teknis tersimpan aman dan teratur.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Side - Form Register -->
        <div class="w-full lg:w-1/2 flex items-center justify-center p-4 h-full">
            <div class="w-full max-w-xl h-full flex items-center py-10">
                <div class="form-glass rounded-3xl shadow-2xl p-8 w-full max-h-full flex flex-col">
                    <div class="flex items-center justify-between mb-6">
                        <div>
                            <h2 class="text-2xl font-bold text-white mb-1">Daftar Akun</h2>
                            <p class="text-sm text-white/50">Lengkapi data untuk membuat akun klien</p>
                        </div>
                        <div class="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center">
                            <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/></svg>
                        </div>
                    </div>

                    @if ($errors->any())
                        <div class="mb-4 bg-red-500/20 border-l-4 border-red-500 text-red-200 px-4 py-2 rounded-xl text-xs">
                            <p class="font-medium">{{ $errors->first() }}</p>
                        </div>
                    @endif

                    <!-- Scrollable Area -->
                    <div class="flex-1 overflow-y-auto pr-2 custom-scrollbar">
                        <form method="POST" action="{{ route('register.submit') }}" class="space-y-4">
                            @csrf
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="text-xs font-semibold text-white/70 mb-1.5 block">Nama Lengkap</label>
                                    <input type="text" name="name" value="{{ old('name') }}" required
                                        class="w-full px-4 py-3 rounded-xl bg-white/5 border-2 border-white/10 focus:border-blue-500 transition-all text-sm text-white"
                                        placeholder="Jules">
                                </div>
                                <div>
                                    <label class="text-xs font-semibold text-white/70 mb-1.5 block">Email</label>
                                    <input type="email" name="email" value="{{ old('email') }}" required
                                        class="w-full px-4 py-3 rounded-xl bg-white/5 border-2 border-white/10 focus:border-blue-500 transition-all text-sm text-white"
                                        placeholder="jules@example.com">
                                </div>
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="text-xs font-semibold text-white/70 mb-1.5 block">Password</label>
                                    <input type="password" name="password" required
                                        class="w-full px-4 py-3 rounded-xl bg-white/5 border-2 border-white/10 focus:border-blue-500 transition-all text-sm text-white"
                                        placeholder="••••••••">
                                </div>
                                <div>
                                    <label class="text-xs font-semibold text-white/70 mb-1.5 block">Konfirmasi Password</label>
                                    <input type="password" name="password_confirmation" required
                                        class="w-full px-4 py-3 rounded-xl bg-white/5 border-2 border-white/10 focus:border-blue-500 transition-all text-sm text-white"
                                        placeholder="••••••••">
                                </div>
                            </div>

                            <div>
                                <label class="text-xs font-semibold text-white/70 mb-1.5 block">Nama Perusahaan / Instansi</label>
                                <input type="text" name="perusahaan" value="{{ old('perusahaan') }}" required
                                    class="w-full px-4 py-3 rounded-xl bg-white/5 border-2 border-white/10 focus:border-blue-500 transition-all text-sm text-white"
                                    placeholder="PT. Eco Maju Bersama">
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="text-xs font-semibold text-white/70 mb-1.5 block">Jabatan</label>
                                    <input type="text" name="jabatan" value="{{ old('jabatan') }}" required
                                        class="w-full px-4 py-3 rounded-xl bg-white/5 border-2 border-white/10 focus:border-blue-500 transition-all text-sm text-white"
                                        placeholder="Direktur Utama">
                                </div>
                                <div>
                                    <label class="text-xs font-semibold text-white/70 mb-1.5 block">Nomor Telepon</label>
                                    <input type="text" name="no_telp" value="{{ old('no_telp') }}" required
                                        class="w-full px-4 py-3 rounded-xl bg-white/5 border-2 border-white/10 focus:border-blue-500 transition-all text-sm text-white"
                                        placeholder="081234567890">
                                </div>
                            </div>

                            <div>
                                <label class="text-xs font-semibold text-white/70 mb-1.5 block">Alamat Kantor</label>
                                <textarea name="alamat" required rows="2"
                                    class="w-full px-4 py-3 rounded-xl bg-white/5 border-2 border-white/10 focus:border-blue-500 transition-all text-sm text-white resize-none"
                                    placeholder="Jl. Raya Utama No. 123, Jakarta"></textarea>
                            </div>

                            <button type="submit"
                                class="w-full btn-glow text-white font-bold py-4 rounded-xl shadow-lg mt-2">
                                Buat Akun Sekarang
                            </button>
                        </form>
                    </div>

                    <div class="mt-6 text-center">
                        <p class="text-sm text-white/40">Sudah punya akun? <a href="{{ route('login') }}" class="text-blue-400 font-bold hover:underline">Masuk di sini</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
