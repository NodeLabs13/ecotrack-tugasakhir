@extends('layouts.app')
@section('title', 'Dashboard')

@section('content')
<div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
    <!-- Card Total Proyek -->
    <div class="bg-gradient-to-br from-primary-500 to-primary-600 rounded-2xl p-6 shadow-lg text-white relative overflow-hidden">
        <div class="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -mr-8 -mt-8"></div>
        <div class="relative">
            <div class="flex items-center gap-3 mb-3">
                <div class="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path>
                    </svg>
                </div>
                <p class="text-sm font-medium opacity-90">Total Proyek</p>
            </div>
            <p class="text-4xl font-bold mb-1">{{ $totalProyek }}</p>
            <p class="text-xs opacity-75">Keseluruhan proyek</p>
        </div>
    </div>

    <!-- Card Proyek Berjalan -->
    <div class="bg-gradient-to-br from-accent-500 to-accent-600 rounded-2xl p-6 shadow-lg text-white relative overflow-hidden">
        <div class="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -mr-8 -mt-8"></div>
        <div class="relative">
            <div class="flex items-center gap-3 mb-3">
                <div class="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                    </svg>
                </div>
                <p class="text-sm font-medium opacity-90">Proyek Berjalan</p>
            </div>
            <p class="text-4xl font-bold mb-1">{{ $proyekBerjalan }}</p>
            <p class="text-xs opacity-75">Sedang dikerjakan</p>
        </div>
    </div>

    <!-- Card Proyek Selesai -->
    <div class="bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl p-6 shadow-lg text-white relative overflow-hidden">
        <div class="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -mr-8 -mt-8"></div>
        <div class="relative">
            <div class="flex items-center gap-3 mb-3">
                <div class="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
                <p class="text-sm font-medium opacity-90">Proyek Selesai</p>
            </div>
            <p class="text-4xl font-bold mb-1">{{ $proyekSelesai }}</p>
            <p class="text-xs opacity-75">Telah diselesaikan</p>
        </div>
    </div>

    <!-- Card Total Klien / Dokumen -->
    <div class="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl p-6 shadow-lg text-white relative overflow-hidden">
        <div class="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -mr-8 -mt-8"></div>
        <div class="relative">
            <div class="flex items-center gap-3 mb-3">
                <div class="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    @if(auth()->user()->isKlien())
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                    </svg>
                    @else
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                    </svg>
                    @endif
                </div>
                <p class="text-sm font-medium opacity-90">
                    {{ auth()->user()->isKlien() ? 'Dokumen Saya' : 'Total Klien' }}
                </p>
            </div>
            <p class="text-4xl font-bold mb-1">
                {{ auth()->user()->isKlien() ? $totalDokumen : $totalKlien }}
            </p>
            <p class="text-xs opacity-75">{{ auth()->user()->isKlien() ? 'Dokumen proyek' : 'Klien terdaftar' }}</p>
        </div>
    </div>
</div>

<!-- Tabel Proyek -->
<div class="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
    <div class="px-6 py-5 border-b border-gray-100 flex items-center justify-between bg-gradient-to-r from-gray-50 to-white">
        <div>
            <h3 class="font-bold text-gray-800 text-lg">Ringkasan Perkembangan Proyek</h3>
            <p class="text-sm text-gray-500 mt-1">Daftar proyek terbaru dan statusnya</p>
        </div>
        <a href="{{ route('proyek.index') }}" class="flex items-center gap-2 text-sm text-primary-600 font-semibold hover:text-primary-700 transition-colors">
            <span>Lihat Semua</span>
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
            </svg>
        </a>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="bg-gradient-to-r from-gray-50 to-gray-100 text-gray-600 text-xs uppercase tracking-wider">
                <tr>
                    <th class="text-left px-6 py-4 font-semibold">Kode</th>
                    <th class="text-left px-6 py-4 font-semibold">Nama Proyek</th>
                    @unless(auth()->user()->isKlien())
                    <th class="text-left px-6 py-4 font-semibold">Klien</th>
                    @endunless
                    <th class="text-left px-6 py-4 font-semibold">Status</th>
                    <th class="text-left px-6 py-4 font-semibold">Tanggal Mulai</th>
                    <th class="text-left px-6 py-4 font-semibold">Tanggal Selesai</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                @forelse($proyekList as $p)
                <tr class="hover:bg-gradient-to-r hover:from-primary-50/30 hover:to-accent-50/30 cursor-pointer transition-all duration-200" onclick="window.location='{{ route('proyek.show', $p) }}'">
                    <td class="px-6 py-4">
                        <span class="font-semibold text-primary-600">{{ $p->kode_proyek }}</span>
                    </td>
                    <td class="px-6 py-4">
                        <span class="font-medium text-gray-800">{{ $p->nama_proyek }}</span>
                    </td>
                    @unless(auth()->user()->isKlien())
                    <td class="px-6 py-4">
                        <div class="flex items-center gap-2">
                            <div class="w-8 h-8 rounded-full bg-gradient-to-br from-primary-400 to-accent-500 flex items-center justify-center text-white text-xs font-bold">
                                {{ substr($p->klien->nama_klien ?? 'N', 0, 1) }}
                            </div>
                            <span class="text-gray-700">{{ $p->klien->nama_klien ?? '-' }}</span>
                        </div>
                    </td>
                    @endunless
                    <td class="px-6 py-4">
                        @if($p->status_proyek == 'selesai')
                        <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-gradient-to-r from-green-100 to-emerald-100 text-green-700 border border-green-200">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            Selesai
                        </span>
                        @elseif($p->status_proyek == 'tertunda')
                        <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-gradient-to-r from-amber-100 to-yellow-100 text-amber-700 border border-amber-200">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            Tertunda
                        </span>
                        @else
                        <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-gradient-to-r from-primary-100 to-accent-100 text-primary-700 border border-primary-200">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                            </svg>
                            Berjalan
                        </span>
                        @endif
                    </td>
                    <td class="px-6 py-4">
                        <span class="text-sm text-gray-600">{{ optional($p->tanggal_mulai)->format('d M Y') ?? '-' }}</span>
                    </td>
                    <td class="px-6 py-4">
                        <span class="text-sm text-gray-600">{{ optional($p->tanggal_selesai)->format('d M Y') ?? '-' }}</span>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="{{ auth()->user()->isKlien() ? 5 : 6 }}" class="px-6 py-12 text-center">
                        <div class="flex flex-col items-center gap-3">
                            <div class="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center">
                                <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
                                </svg>
                            </div>
                            <div>
                                <p class="text-gray-500 font-medium">Belum ada data proyek</p>
                                <p class="text-sm text-gray-400 mt-1">Proyek akan muncul di sini setelah ditambahkan</p>
                            </div>
                        </div>
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
